#!/usr/bin/python
#-*-coding: utf-8-*-
#file_name:ChanE
#file_author:dongjundong
#function: test ChanE
#date: 2018-03-27

import unittest
from ChanE import *

class TestChanE(unittest.TestCase):
    def test_turn_right(self):
        result = exec_cmd('East', [0, 0], 'rR')
        self.assertEqual(result, ('West', [0, 0]))

    def test_turn_left(self):
        result = exec_cmd('East', [0, 0], 'Ll')
        self.assertEqual(result, ('West', [0, 0]))

    def test_turn_forward(self):
        result = exec_cmd('East', [0, 0], 'fF')
        self.assertEqual(result, ('East', [2, 0]))

    def test_invalid_command(self):
        result = exec_cmd('East', [0, 0], 'tyuie')
        self.assertEqual(result, ('East', [0, 0]))

    def test_mix_command(self):
        result = exec_cmd('East', [0, 0], 'fltyfruirfef')
        self.assertEqual(result, ('South', [1, -1]))
        
if __name__ == '__main__':
    unittest.main()