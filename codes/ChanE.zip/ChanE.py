#!/usr/bin/python
#-*-coding: utf-8-*-
#file_name:ChanE
#file_author:dongjundong
#function: execute command ,return position and direction
#date: 2018-03-27

import re
import numpy as np

DIRECTION = {0: 'East', 1: 'North', 2: 'West', 3: 'South'}
DIRECTION_REV = {'East': 0, 'North': 1, 'West': 2, 'South': 3}
MOVE_ACTION =  {'East': (1, 0), 'North': (0, 1), 'West': (-1, 0), 'South': (0, -1)}

#get direction after turn
def get_direction(cmd, direction):
    l_num = len(re.findall('L', cmd))
    r_num = len(re.findall('R', cmd))
    cur_direction = DIRECTION[((l_num-r_num)+DIRECTION_REV[direction])%4]
    return cur_direction

#return final direction and position after execute all command
def exec_cmd(defalut_direction, defalut_position, cmd_str):
    direction = defalut_direction
    position = defalut_position
    cmd_str = cmd_str.upper()
    cmd_str = ''.join([single for single in cmd_str if single in 'LRF'])
    cmd_list_pre = cmd_str.replace('F', '|F|').split('|')
    cmd_list = list(filter(lambda x: x != '', cmd_list_pre))
    print('valid command list', cmd_list)
    for cmd in cmd_list:
        if re.search('R|L', cmd):
            direction = get_direction(cmd, direction)
            continue
        step_change = len(cmd) * np.array(MOVE_ACTION[direction])
        position = position + step_change
    return direction, list(position)

if __name__ == '__main__':
    promot = '''
            input  the command you wanna execute:
            eg:FFFLRFL or ffflrfl
            F|f: forward
            R|r: turn right
            L|l: turn left
            '''
    defalut_direction = 'East'
    defalut_position = [0, 0]
    cmd_str = input(promot)
    final_result = exec_cmd(defalut_direction, defalut_position, cmd_str)
    print('final direction and position:\n   ', final_result)