程序在Windows7 python 3.6.2下调试通过
ChanE.py 为要求代码
TestChanE.py 为单元测试